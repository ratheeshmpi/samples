import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CmpCheck1Component } from './cmp-check1/cmp-check1.component';
import { MdlSampleModule } from './mdl-sample/mdl-sample.module';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import {enableProdMode} from '@angular/core';


enableProdMode()
@NgModule({
  declarations: [
    AppComponent,
    CmpCheck1Component
],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MdlSampleModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule

  ],
  providers: [],

  bootstrap: [AppComponent]
})

export class AppModule { }
