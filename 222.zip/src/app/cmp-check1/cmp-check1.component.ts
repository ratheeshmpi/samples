import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmp-check1',
  templateUrl: './cmp-check1.component.html',
  styleUrls: ['./cmp-check1.component.css']
})
export class CmpCheck1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
