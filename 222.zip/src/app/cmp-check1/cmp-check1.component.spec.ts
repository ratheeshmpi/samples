import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpCheck1Component } from './cmp-check1.component';

describe('CmpCheck1Component', () => {
  let component: CmpCheck1Component;
  let fixture: ComponentFixture<CmpCheck1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmpCheck1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpCheck1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
