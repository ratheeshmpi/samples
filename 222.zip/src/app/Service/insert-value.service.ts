import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { InsertValue } from '../Classes/Insert';

@Injectable({
  providedIn: 'root'
})
export class InsertValueService {
private readonly url="https://localhost:5001/api/"
  constructor(private http:HttpClient) { }
  AddInsertValue(objInsertValue:InsertValue): Observable<any>
  {
    debugger;
    return this.http.post(this.url+'Checking/AddInsertValue'
    ,objInsertValue,{responseType:'text'});
  }
  // EditUserDetails(objuserid:InsertValue):Observable<any>
  // {
  //   return this.http.post(this.url+'Checking/EditGetDetails',objuserId,{responseType:'text'});
  // }
  GetUserDetails():Observable<any>
  {
    debugger;
    return this.http.get(this.url+'Checking/GetValue');
  }
  // EditUserDetails(objinsert:InsertValue):Observable<any>
  // {
  //   return this.http.post(this.url+'Checking/EditUserDetails',objinsert,{responseType:'text'});
  // }
  DeleteUserDetails(objinsert:InsertValue):Observable<any>
  {
    return this.http.post(this.url+'Checking/DeleteUserDetails',objinsert,{responseType:'text'});
  }
  EditUserDetails(objInsertValue:InsertValue): Observable<any>
  {
    debugger;
    return this.http.post(this.url+'Checking/EditUserDetails',objInsertValue,{responseType:'text'});
  }

}
