import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmptEditComponent } from './cmpt-edit.component';

describe('CmptEditComponent', () => {
  let component: CmptEditComponent;
  let fixture: ComponentFixture<CmptEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmptEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmptEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
