import { Component, OnInit } from '@angular/core';
import { InsertValue } from 'src/app/Classes/Insert';
import { InsertValueService } from 'src/app/Service/insert-value.service';
import { error } from 'util';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-cmpt-edit',
  templateUrl: './cmpt-edit.component.html',
  styleUrls: ['./cmpt-edit.component.css']
})
export class CmptEditComponent implements OnInit {
  ValueInsert:FormGroup;
  constructor(private formBuilder:FormBuilder,private _appService:InsertValueService) 
  { }

  ngOnInit() {
    this.ValueInsertfunc();
  }
  ValueInsertfunc() {
    this.ValueInsert=this.formBuilder.group({
      UserId:['',Validators.required],
      UserName:['',Validators.required]
    });
  }
  get insert(){
    return this.ValueInsert.controls;
  }
  onSubmit(){
    debugger;
    if(this.ValueInsert.invalid)
    {
      return;
    }
    var objInsertValue=new InsertValue();
    objInsertValue.UserId=this.insert.UserId.value;
    objInsertValue.UserName=this.insert.UserName.value;
    this._appService.EditUserDetails(objInsertValue)
    .subscribe(
      (data:string)=>{
        alert("reponse:"+data);
      },
      error=>
      {

      }
    );
  
  }

}
