import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators}from '@angular/forms';
import {InsertValue} from 'src/app/Classes/Insert';
import { from } from 'rxjs';
import { error } from 'util';
import { InsertValueService } from 'src/app/Service/insert-value.service';
@Component({
  selector: 'app-cmp-insert',
  templateUrl: './cmp-insert.component.html',
  styleUrls: ['./cmp-insert.component.css']
})
export class CmpInsertComponent implements OnInit {
ValueInsert:FormGroup;
  constructor(
    private formBuilder:FormBuilder,private _appService:InsertValueService
  ) { }

  ngOnInit() {
    this.ValueInsertfunc();
  }
  ValueInsertfunc() {
    this.ValueInsert=this.formBuilder.group({
      userId:['',Validators.required],
      userName:['',Validators.required]
    });
  }
  get insert(){
    return this.ValueInsert.controls;
  }
  onSubmit(){
    debugger;
    if(this.ValueInsert.invalid)
    {
      return;
    }
    var objInsertValue=new InsertValue();
    objInsertValue.UserId=this.insert.userId.value;
    objInsertValue.UserName=this.insert.userName.value;
    this._appService.AddInsertValue(objInsertValue)
    .subscribe(
      (data:string)=>{
        alert("reponse:"+data);
      },
      error=>
      {
        

      }
    )
  }

}
