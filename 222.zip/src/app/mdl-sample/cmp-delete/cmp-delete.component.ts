import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators,NgForm } from '@angular/forms';
import { InsertValue } from 'src/app/Classes/Insert';
import { InsertValueService } from 'src/app/Service/insert-value.service';
import { error } from 'util';

@Component({
  selector: 'app-cmp-delete',
  templateUrl: './cmp-delete.component.html',
  styleUrls: ['./cmp-delete.component.css']
})
export class CmpDeleteComponent implements OnInit {
objUserDetail:InsertValue[];
ValueDelete:FormGroup;
  constructor(private _appService:InsertValueService, private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.Delete();
  }
  
  Delete() {
    this.ValueDelete=this.formBuilder.group({
      userId:['',Validators.required],
      userName:['',Validators.required]
    });
  }

    
  get DeleteAcc()
  {
    return this.ValueDelete.controls;
  }

  
  onSubmit(){
    debugger;
    if(this.ValueDelete.invalid)
    {
      return;
    }
    var objInsertValue=new InsertValue();
    objInsertValue.UserId=this.DeleteAcc.userId.value;
    objInsertValue.UserName=this.DeleteAcc.userName.value;
    this._appService.DeleteUserDetails(objInsertValue)
    .subscribe(
      (data:string)=>{
        alert("reponse:"+data);
      },
      error=>
      {

      }
    );
  }

}
