import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpDeleteComponent } from './cmp-delete.component';

describe('CmpDeleteComponent', () => {
  let component: CmpDeleteComponent;
  let fixture: ComponentFixture<CmpDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmpDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
