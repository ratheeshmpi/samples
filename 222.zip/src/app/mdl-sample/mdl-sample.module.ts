import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CmpInsertComponent } from './cmp-insert/cmp-insert.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CmptEditComponent } from './cmpt-edit/cmpt-edit.component';
import { CmpDeleteComponent } from './cmp-delete/cmp-delete.component';
import { CmpdashboardComponent } from './cmpdashboard/cmpdashboard.component';



@NgModule({
  declarations: [CmpInsertComponent, CmptEditComponent, CmpDeleteComponent, CmpdashboardComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports:[CmpInsertComponent,
    CmptEditComponent,
    CmpDeleteComponent,
    CmpdashboardComponent]
})
export class MdlSampleModule { }
