import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpdashboardComponent } from './cmpdashboard.component';

describe('CmpdashboardComponent', () => {
  let component: CmpdashboardComponent;
  let fixture: ComponentFixture<CmpdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmpdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
