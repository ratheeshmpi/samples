import { Component, OnInit } from '@angular/core';
import { InsertValue } from 'src/app/Classes/Insert';
import { InsertValueService } from 'src/app/Service/insert-value.service';
import { Router } from '@angular/router';
import { error } from 'util';

@Component({
  selector: 'app-cmpdashboard',
  templateUrl: './cmpdashboard.component.html',
  styleUrls: ['./cmpdashboard.component.css']
})
export class CmpdashboardComponent implements OnInit {
objUserDetail:InsertValue[];
UserTable:boolean=false;
editpage:boolean=true;
  constructor(private _appService:InsertValueService,private router:Router) { }

  ngOnInit() {
    this.GetUserDetails();
  }
  GetUserDetails()
  {
    debugger;
    this._appService.GetUserDetails()
    .subscribe(
      (data: InsertValue[]) =>{
        this.objUserDetail = data;
      },
      error =>{

      }
    );
  }
Edit(userId:string)
{
  debugger;
  var objUserId=new InsertValue();
  objUserId.UserId=userId;
  this._appService.EditUserDetails(objUserId)
  .subscribe(data=>{this.UserTable=true;
    this.editpage=false;
  },
  error=>
  {

  });
}
AddNew()
{
  this.router.navigate(['/insert']);
}
}
