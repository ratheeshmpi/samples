export class InsertValue
{
    UserId: string;
    UserName: string;
}