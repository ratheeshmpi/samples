export class StaffModel
{
    StaffID:number;
    StaffName:string;
    Gender:string;
    Mobile:string;
    Department:string;
    Address:string;
    Email:string;
    Password:string;
    Salary:string;
    Photo:string;    
}