import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ServiceFileService } from 'src/app/ServiceFile/service-file.service';
import { Router } from '@angular/router';
import { StaffModel } from '../Classes/ModelClass';

@Component({
  selector: 'app-cmp-login',
  templateUrl: './cmp-login.component.html',
  styleUrls: ['./cmp-login.component.css']
})
export class CmpLoginComponent implements OnInit {
ValueInsert:FormGroup
  constructor(private formBuilder:FormBuilder,
              private _appservice:ServiceFileService,
              private router:Router) { }

  ngOnInit() {
    this.LoginFunct();
  }
LoginFunct()
{
  this.ValueInsert=this.formBuilder.group(
    {
        StaffID:['',Validators.required],
        Password:['',Validators.required]
    }
  );
}
get login()
{
  return this.ValueInsert.controls;
}
onSubmit()
{

  if(this.ValueInsert.invalid)
  {
    return;
  }
  var objstaffmodel=new StaffModel();
  objstaffmodel.StaffID=this.login.StaffID.value;
  objstaffmodel.Password=this.login.Password.value;
  this._appservice.LoginForm(objstaffmodel)
  .subscribe(
    (data:string)=>{
      alert("response"+data);
    },
    error=>
    {
  
    }
    );
}
}
