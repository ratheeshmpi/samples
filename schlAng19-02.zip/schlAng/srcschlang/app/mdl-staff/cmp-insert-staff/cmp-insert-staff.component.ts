import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ServiceFileService } from 'src/app/ServiceFile/service-file.service';
import { Router } from '@angular/router';
import { StaffModel } from 'src/app/Classes/ModelClass';
import { error } from 'util';

@Component({
  selector: 'app-cmp-insert-staff',
  templateUrl: './cmp-insert-staff.component.html',
  styleUrls: ['./cmp-insert-staff.component.css']
})
export class CmpInsertStaffComponent implements OnInit {
ValueInsert:FormGroup;
  constructor(private formBuilder:FormBuilder,
              private _appservice:ServiceFileService,
              private router:Router) { }

  ngOnInit() {
    this.InsertFunction();
  }
  InsertFunction()
  {
    this.ValueInsert=this.formBuilder.group(
      {
        StaffName:['',Validators.required],
        Gender:['',Validators.required],
        Mobile:['',Validators.required],
        Department:['',Validators.required],
        Address:['',Validators.required],
        Email:['',Validators.required],
        Password:['',Validators.required],
        Salary:['',Validators.required],
        Photo:['',Validators.required]
      }
    );
  }
get add()
{
  return this.ValueInsert.controls;
}
onSubmit()
{
  
  if(this.ValueInsert.invalid)
  {
    return;
  }
  var objstaffmodel=new StaffModel();
  objstaffmodel.StaffName=this.add.StaffName.value;
  objstaffmodel.Gender=this.add.Gender.value;
  objstaffmodel.Mobile=this.add.Mobile.value;
  objstaffmodel.Department=this.add.Department.value;
  objstaffmodel.Address=this.add.Address.value;
  objstaffmodel.Email=this.add.Email.value;
  objstaffmodel.Password=this.add.Password.value;
  objstaffmodel.Salary=this.add.Salary.value;
  objstaffmodel.Password=this.add.Password.value;
  objstaffmodel.Photo=this.add.Photo.value;
  this._appservice.InsertStaff(objstaffmodel)
  .subscribe(
  (data:string)=>{
    alert("response"+data);
  },
  error=>
  {

  }
  );
}
}

