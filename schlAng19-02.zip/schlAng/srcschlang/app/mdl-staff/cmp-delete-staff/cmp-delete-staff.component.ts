import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ServiceFileService } from 'src/app/ServiceFile/service-file.service';
import { StaffModel } from 'src/app/Classes/ModelClass';
import { error } from 'util';

@Component({
  selector: 'app-cmp-delete-staff',
  templateUrl: './cmp-delete-staff.component.html',
  styleUrls: ['./cmp-delete-staff.component.css']
})
export class CmpDeleteStaffComponent implements OnInit {
ValueInsert:FormGroup
  constructor(private formBuilder:FormBuilder,
              private _appservice:ServiceFileService) { }

  ngOnInit() {
    this.Deletefunc();
  }
  Deletefunc()
  {
    this.ValueInsert=this.formBuilder.group(
      {
        StaffID:['',Validators.required]
      }
    );

  }
  get delete()
  {
    return this.ValueInsert.controls;
  }
onSubmit()
{
  if(this.ValueInsert.invalid)
  {
    return;
  }
  var objstaffmodel=new StaffModel();
  objstaffmodel.StaffID=this.delete.StaffID.value;
  this._appservice.DeleteStaff(objstaffmodel)
  .subscribe(
    (data:string)=>
    {
      alert("reponse:"+data);
    },
    error=>
    {

    }
  )
}
}
