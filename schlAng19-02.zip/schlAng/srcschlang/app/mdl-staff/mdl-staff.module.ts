import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { CmpInsertStaffComponent } from './cmp-insert-staff/cmp-insert-staff.component';
import { CmpEditStaffComponent } from './cmp-edit-staff/cmp-edit-staff.component';
import { CmpDeleteStaffComponent } from './cmp-delete-staff/cmp-delete-staff.component';
import { CmpLoginComponent } from './cmp-login/cmp-login.component';




@NgModule({
  declarations: [CmpInsertStaffComponent, CmpEditStaffComponent,CmpDeleteStaffComponent, CmpLoginComponent ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    BrowserModule
  ],
  exports:[CmpInsertStaffComponent,CmpEditStaffComponent,CmpDeleteStaffComponent,CmpLoginComponent]
})
export class MdlStaffModule { }
