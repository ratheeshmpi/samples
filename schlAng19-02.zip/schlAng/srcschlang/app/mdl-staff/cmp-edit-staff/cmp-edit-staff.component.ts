import { Component, OnInit } from '@angular/core';
import { StaffModel } from 'src/app/Classes/ModelClass';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServiceFileService } from 'src/app/ServiceFile/service-file.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cmp-edit-staff',
  templateUrl: './cmp-edit-staff.component.html',
  styleUrls: ['./cmp-edit-staff.component.css']
})
export class CmpEditStaffComponent implements OnInit {
ValueInsert:FormGroup;
  constructor(private formBuilder:FormBuilder,
              private appservice:ServiceFileService,
              private router:Router) { }

  ngOnInit() {
    this.EditFunc();
  }
  EditFunc()
  {
    this.ValueInsert=this.formBuilder.group(
      {
        StaffID:['',Validators.required],
        StaffName:['',Validators.required],
        Gender:['',Validators.required],
        Mobile:['',Validators.required],
        Department:['',Validators.required],
        Address:['',Validators.required],
        Email:['',Validators.required],
        Password:['',Validators.required],
        Salary:['',Validators.required],
        Photo:['',Validators.required]
      }
      );
      }
      get edit()
      {
        return this.ValueInsert.controls;
      }
onSubmit()
{
  if(this.ValueInsert.invalid)
  {
    return;
  }
  var objstaffmodel=new StaffModel();
  objstaffmodel.StaffID=this.edit.StaffID.value;
   objstaffmodel.StaffName=this.edit.StaffName.value;
  objstaffmodel.Gender=this.edit.Gender.value;
  objstaffmodel.Mobile=this.edit.Mobile.value;
  objstaffmodel.Department=this.edit.Department.value;
  objstaffmodel.Address=this.edit.Address.value;
  objstaffmodel.Email=this.edit.Email.value;
  objstaffmodel.Password=this.edit.Password.value;
  objstaffmodel.Salary=this.edit.Salary.value;
  objstaffmodel.Password=this.edit.Password.value;
  objstaffmodel.Photo=this.edit.Photo.value;
  this.appservice.Updatestaff(objstaffmodel)
  .subscribe(
    (data:string)=>{
      alert("response:"+data);
      //this.router.navigate(['']);
    },
    error=>
    {

    }
  )
}
}
