import { Injectable } from '@angular/core';
import {HttpClient} from'@angular/common/http';
import { from, Observable } from 'rxjs';
import { StaffModel } from '../Classes/ModelClass';

@Injectable({
  providedIn: 'root'
})
export class ServiceFileService {
 
private readonly url= "https://localhost:5001/api/";
  constructor(private http:HttpClient,) { }
  
  // StaffList(): Observable<any>{
  //   debugger;
  //   return this.http.post(this.url + 'SchoolMgt/StaffIndex', {responseType: 'text'});
  // }
  StaffList():Observable<any>
  
  {
    debugger;
    return this.http.get(this.url+'SchoolMgt/StaffIndex');
  }
  InsertStaff(objstaffmodel:StaffModel):Observable<any>
  {
    return this.http.post(this.url+'SchoolMgt/InsertStaff',objstaffmodel,{responseType:'text'})
  }
  Updatestaff(objstaffmodel:StaffModel):Observable<any>
  {
    return this.http.post(this.url+'SchoolMgt/Updatestaff',objstaffmodel,{responseType:'text'})
  }
  DeleteStaff(objstaffmodel:StaffModel):Observable<any>
  {
    return this.http.post(this.url+'SchoolMgt/DeleteStaff',objstaffmodel,{responseType:'text'})
  }
  LoginForm(objstaffmodel:StaffModel):Observable<any>
  {
    return this.http.post(this.url+'SchoolMgt/Login',objstaffmodel,{responseType:'text'})
  }
}
