import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CmpLoginComponent } from './mdl-staff/cmp-login/cmp-login.component';


const routes: Routes = [
  {path:"login",component:CmpLoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
