using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using System.IO;


namespace SchoolManagement.Model
{

    public class DAL
    {
        string strConn = "Server=MPI-CPU-102\\SQLEXPRESS;Database=SchoolManagement;User Id=sa;Password=m@jdev1";


        public void CreateStaff(string StaffName, string Gender, string Mobile, string Department, string Address, string Email, string Password, string Salary, string Photo)
        {
            using (SqlConnection con = new SqlConnection(strConn))
            {

                //var fn= Path.GetFileName(paths.FileName);
                //var path = $"{Directory.GetCurrentDirectory()}{@"\wwwroot\Images\"}" + fn;
                con.Open();
                SqlCommand cmd = new SqlCommand("CreateStaff", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("StaffName", StaffName);
                cmd.Parameters.AddWithValue("Gender", Gender);
                cmd.Parameters.AddWithValue("Mobile", Mobile);
                cmd.Parameters.AddWithValue("Department", Department);
                cmd.Parameters.AddWithValue("Address", Address);
                cmd.Parameters.AddWithValue("Email", Email);
                cmd.Parameters.AddWithValue("Password", Password);
                cmd.Parameters.AddWithValue("Salary", Salary);
                cmd.Parameters.AddWithValue("Photo", Photo);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public void CreateStudent(string StudentName, string Class, string Email, string Password, string Photo)
        {
            using (SqlConnection con = new SqlConnection(strConn))
            {
                //var fn= Path.GetFileName(paths.FileName);
                //var path = $"{Directory.GetCurrentDirectory()}{@"\wwwroot\Images\"}" + fn;
                con.Open();
                SqlCommand cmd = new SqlCommand("CreateStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("StudentName", StudentName);
                cmd.Parameters.AddWithValue("Class", Class);
                cmd.Parameters.AddWithValue("Email", Email);
                cmd.Parameters.AddWithValue("Password", Password);

                cmd.Parameters.AddWithValue("Photo", Photo);



                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        public void StaffUpdate(int StaffID, string StaffName, string Gender, string Mobile, string Department, string Address, string Email, string Password, string Salary, string Photo)
        {
            using (SqlConnection con = new SqlConnection(strConn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("db_StaffUpdate", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("StaffID", StaffID);
                cmd.Parameters.AddWithValue("StaffName", StaffName);
                cmd.Parameters.AddWithValue("Gender", Gender);
                cmd.Parameters.AddWithValue("Mobile", Mobile);
                cmd.Parameters.AddWithValue("Department", Department);
                cmd.Parameters.AddWithValue("Address", Address);
                cmd.Parameters.AddWithValue("Email", Email);
                cmd.Parameters.AddWithValue("Password", Password);
                cmd.Parameters.AddWithValue("Salary", Salary);
                cmd.Parameters.AddWithValue("Photo", Photo);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        public void StudentUpdate(int StudentId, string StudentName, string Class, string Email, string Password, string Photo)
        {
            using (SqlConnection con = new SqlConnection(strConn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("db_UpdateStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("StudentId", StudentId);
                cmd.Parameters.AddWithValue("StudentName", StudentName);
                cmd.Parameters.AddWithValue("Class", Class);
                cmd.Parameters.AddWithValue("Email", Email);
                cmd.Parameters.AddWithValue("Password", Password);
                cmd.Parameters.AddWithValue("Photo", Photo);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        public void StaffDelete(int StaffID)
        {
            Staff objcol = new Staff();
            using (SqlConnection con = new SqlConnection(strConn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DeleteStaff", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("StaffID", StaffID);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }


        public void StudentDelete(int StudentId)
        {
            Student objcol = new Student();
            using (SqlConnection con = new SqlConnection(strConn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DeleteStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("StudentId", StudentId);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        public string Loginfunction(string UserName, string Password)
        {
           string Success = "";
            using (SqlConnection con = new SqlConnection(strConn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("UspLoginUser", con);
              
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserName", UserName);
                cmd.Parameters.AddWithValue("@Password", Password);
                // cmd.Parameters.AddWithValue("@a", a);

               // cmd.Parameters.AddWithValue("@Result", ParameterDirection.Output);  
                //cmd.Parameters["@Result"].Value.ToString();
                 SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();   
                sda.Fill(dt);
                cmd.ExecuteNonQuery();
                con.Close();

                if (dt.Rows.Count > 0)
                {
                    Success = Convert.ToString(dt.Rows[0]["result"]);
                }
           return  Success;
            }
        }
        public IEnumerable<Staff> StaffDetails()
        {
            List<Staff> list = new List<Staff>();
            Staff staff = new Staff();
            using (SqlConnection con = new SqlConnection(strConn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Staff", con);
                cmd.CommandType = CommandType.Text;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    staff = new Staff();
                    staff.StaffID = Convert.ToInt32(dr["StaffID"]);
                    staff.StaffName = dr["StaffName"].ToString();
                    staff.Gender = dr["Gender"].ToString();
                    staff.Mobile = dr["Mobile"].ToString();
                    staff.Department = dr["Department"].ToString();
                    staff.Address = dr["Address"].ToString();
                    staff.Email = dr["Email"].ToString();
                    staff.Password = dr["Password"].ToString();
                    staff.Salary = dr["Salary"].ToString();
                    staff.Photo = dr["Photo"].ToString();
                    list.Add(staff);

                }
                con.Close();
            }
            return list;
        }

        public IEnumerable<Student> StudentDetails()
        {
            List<Student> list = new List<Student>();
            Student student = new Student();
            using (SqlConnection con = new SqlConnection(strConn))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Student", con);
                cmd.CommandType = CommandType.Text;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    student = new Student();
                    student.StudentId = Convert.ToInt32(dr["StudentId"]);
                    student.StudentName = dr["StudentName"].ToString();
                    student.Class = dr["Class"].ToString();
                    student.Email = dr["Email"].ToString();
                    student.Password = dr["Password"].ToString();
                    student.Photo = dr["Photo"].ToString();
                    list.Add(student);
                }
                con.Close();
            }
            return list;
        }
    }
}

