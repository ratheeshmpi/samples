//create

 //https://localhost:5001/api/SchoolMgt/StaffReg?StaffName=test22&&Gender=male&&Mobile=820963147&&Department=BE&&Address=Coimbatore&&Email=aaa@gmail.com&&Password=test123&&Salary=20000&&Photo=pic
//https://localhost:5001/api/SchoolMgt/StudentReg?StudentName=studetest22&&Class=5&&Email=aaa@gmail.com82&&Password=psss222&&Photo=pic
 //update
// https://localhost:5001/api/SchoolMgt/Updatestaff?StaffName=Prabakaran&&Gender=Female&&Mobile=8520963147&&Department=B.Sc&&Address=Thudiaylur&&Email=sathyavathy@yahoo.com&&Password=test123&&Salary=45000&&Photo=Picture%20Sathyavathy&&StaffID=1001
 
 //http://localhost:5001/api/SchoolMgt/Login?UserName=Prabakaran&&Password=test123
 //https://localhost:5001/api/SchoolMgt/StaffIndex
 //https://localhost:5001/api/SchoolMgt/StudentIndex
 
  using System.Collections.Generic;
using SchoolManagement.Model;
using Microsoft.AspNetCore.Mvc;

namespace SchoolManagement.Controllers
{

[ApiController]
    public class SchoolMgtController : ControllerBase
    {

      
      
      
      [HttpGet]
        [Route("api/SchoolMgt/StaffReg")]
         

   public ActionResult<string> StaffReg (string StaffName,string Gender,string Mobile,string Department,string Address,string Email,string Password,string Salary,string Photo)
       { 

             Staff obsf=new Staff();
            new DAL().CreateStaff(StaffName, Gender, Mobile, Department, Address, Email, Password, Salary, Photo);
         //return RedirectToAction("Index");
            return "Success"; 
         
        }
         
        
         [HttpGet]
        [Route("api/SchoolMgt/StudentReg")]
         

   public ActionResult<string> StudentReg (string StudentName,string Class,string Email,string Password,string Photo)
       

        { 
             Student obst=new Student();
            new DAL().CreateStudent(StudentName, Class, Email, Password, Photo);
              //return RedirectToAction("Index");
            return "Success"; 
         
        }
[HttpGet]
     [Route("api/SchoolMgt/Updatestaff")]   
     public int Updatestaff(int StaffID,string StaffName,string Gender,string Mobile,string Department,string Address,string Email,string Password,string Salary,string Photo)
     {
         DAL objdal=new DAL();
         objdal =new DAL();
         objdal.StaffUpdate( StaffID, StaffName, Gender, Mobile, Department, Address, Email, Password, Salary, Photo);
         return 1;
     }
     [HttpGet]
     [Route("api/SchoolMgt/UpdateStudent")]
     public int UpdateStudent(int StudentId,string StudentName,string Class,string Email,string Password,string Photo)
     {
         DAL objdal=new DAL();
         objdal=new DAL();
         objdal.StudentUpdate(StudentId,StudentName,Class,Email,Password,Photo);
         return 1;
     }
      [Route("apd/SchoolMgt/DeleteStaff")] 
        [HttpGet]
        public ActionResult <string> DeleteStaff(int StaffID)
        {
            DAL objDAL=new DAL();
            objDAL.StaffDelete(StaffID);
            return "Success";
        }


        [Route("apd/SchoolMgt/DeleteStudent")] 
        [HttpGet]
        public string DeleteStudent(int StudentId)
        {
            DAL objDAL=new DAL();
            objDAL.StudentDelete(StudentId);
            return "Success";
        }
         [HttpGet]
        [Route("api/SchoolMgt/Login")]
       
        public ActionResult<string> Login(string UserName,string Password)
        {
          //System.Diagnostics.Debugger.Launch();
            int a=0;
            var result = new DAL().Loginfunction(UserName,Password);
            if (result == "1")
            {
               return "Hello Student";
            }
            else if(result=="2")
            {
                return "Hello Staff";
            }
            return "Password or Id Incorrect";
        }
        [HttpGet]
        [Route("api/SchoolMgt/StaffIndex")]
        public ActionResult<IEnumerable<Staff>> StaffIndex()
        {
            DAL objdal = new DAL();
            List<Staff> ojstaff = new List<Staff>();
            ojstaff = (List<Staff>)objdal.StaffDetails();
            return ojstaff;
        }

        [HttpGet]
        [Route("api/SchoolMgt/StudentIndex")]
        public ActionResult<IEnumerable<Student>> StudentIndex()
        {
            DAL objdal = new DAL();
            List<Student> ojstu = new List<Student>();
            ojstu = (List<Student>)objdal.StudentDetails();
            return ojstu;
        }
        



    }
}
