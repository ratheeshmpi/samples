﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentRegistration.Models
{
    public class Registration
    {
        public int ID { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DOB { get; set; }
        public string Gender { get; set; }
        public string Email_ID { get; set; }
        public string Mobile_Number { get; set; }
        public int City { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public int IsDeleted { get; set; }
        public int CreatedBy { get; set; }
        public DateTime createdate { get; set; }

        public string updatedBy { get; set; }
        public DateTime updatedDate { get; set; }


       
    }
}