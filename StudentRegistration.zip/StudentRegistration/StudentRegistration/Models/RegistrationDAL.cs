﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace StudentRegistration.Models
{
    
    public class RegistrationDAL
    {
        string cs = ConfigurationManager.ConnectionStrings["SMS"].ConnectionString;

        public List<Registration> Index()
        {
            List<Registration> lst = new List<Registration>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    lst.Add(new Registration
                    {
                        ID = Convert.ToInt32(rdr["Id"]),
                        FirstName = rdr["FirstName"].ToString(),
                        LastName=rdr["LastName"].ToString(),
                        DOB = rdr["DOB"].ToString(),
                        Gender = rdr["Gender"].ToString(),
                        Email_ID = rdr["Email_ID"].ToString(),
                        Mobile_Number = rdr["Mobile_Number"].ToString(),
                        City = Convert.ToInt32(rdr["City"]),
                        State = Convert.ToInt32(rdr["State"]),
                        Country = Convert.ToInt32(rdr["Country"]),
                  

                    });
                }
                return lst;
            }
        }

    


    }
}