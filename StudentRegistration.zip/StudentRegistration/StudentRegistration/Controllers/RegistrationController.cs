﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRegistration.Models;


namespace StudentRegistration.Controllers
{
    public class RegistrationController : Controller
    {
        //
        // GET: /Registration/
        public ActionResult Index()
        {
            RegistrationDAL rgdal = new RegistrationDAL();
            return View();
        }

        public ActionResult ShowwAllstudent()
        {

            return View();
        }
        public ActionResult RegisterStudent()
        {

            return View();
        }

        public ActionResult EditStudent()
        {


            return View();
        }


        public ActionResult DeleteStudent()
        {

            return View();
        }



	}
}