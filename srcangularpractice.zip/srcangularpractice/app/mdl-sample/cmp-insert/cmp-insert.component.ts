import { Component, OnInit } from '@angular/core';
import{FormGroup,FormBuilder,Validators}from '@angular/forms';
import{InsertValue}  from 'src/app/Classes/Insert';
import { InsertValueService } from 'src/app/Services/insert-value.service';


@Component({
  selector: 'app-cmp-insert',
  templateUrl: './cmp-insert.component.html',
  styleUrls: ['./cmp-insert.component.css']
})
export class CmpInsertComponent implements OnInit {
  ValueInsert:FormGroup;
    constructor(
      private formBuilder:FormBuilder,private _appService:InsertValueService
    ) { }

    ngOnInit() {
      this.ValueInsertfunc();
    }
    ValueInsertfunc() {
      this.ValueInsert=this.formBuilder.group({
        UserId:['',Validators.required],
        UserName:['',Validators.required]
      });
    }
    get insert(){
      return this.ValueInsert.controls;
    }
    onSubmit(){
      debugger;
      if(this.ValueInsert.invalid)
      {
        return;
      }
      var objInsertValue=new InsertValue();
      objInsertValue.UserId=this.insert.UserId.value;
      objInsertValue.UserName=this.insert.UserName.value;
      this._appService.AddInsertValue(objInsertValue)
      .subscribe(
        (data:string)=>{
          alert("reponse:"+data);
        },
        error=>
        {


        }
      );
    }

  }
