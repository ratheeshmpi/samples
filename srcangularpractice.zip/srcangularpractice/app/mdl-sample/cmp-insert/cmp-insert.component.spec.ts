import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpInsertComponent } from './cmp-insert.component';

describe('CmpInsertComponent', () => {
  let component: CmpInsertComponent;
  let fixture: ComponentFixture<CmpInsertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmpInsertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpInsertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
