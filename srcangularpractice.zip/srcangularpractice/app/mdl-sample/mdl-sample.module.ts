import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CmpInsertComponent } from './cmp-insert/cmp-insert.component';
import {  CmpEditComponent} from './cmp-edit/cmp-edit.component';
import { CmpDashboardComponent } from './cmp-dashboard/cmp-dashboard.component';
import { CmpDeleteComponent } from './cmp-delete/cmp-delete.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';





@NgModule({
  declarations: [CmpInsertComponent, CmpEditComponent,  CmpDeleteComponent,CmpDashboardComponent],
  imports: [
    CommonModule,
    BrowserModule,
        FormsModule,
        ReactiveFormsModule
  ],
  exports:[CmpInsertComponent,
   CmpEditComponent,
    CmpDeleteComponent,
  CmpDashboardComponent]
})
export class MdlSampleModule { }
