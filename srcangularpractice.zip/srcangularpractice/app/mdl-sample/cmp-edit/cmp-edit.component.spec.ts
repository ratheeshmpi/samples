import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpEditComponent } from './cmp-edit.component';

describe('CmpEditComponent', () => {
  let component: CmpEditComponent;
  let fixture: ComponentFixture<CmpEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmpEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
