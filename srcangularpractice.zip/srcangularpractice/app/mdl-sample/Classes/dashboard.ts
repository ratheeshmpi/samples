export class user{
  UserId: string;
  UserName: string;
}
