import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpDashboardComponent } from './cmp-dashboard.component';

describe('CmpDashboardComponent', () => {
  let component: CmpDashboardComponent;
  let fixture: ComponentFixture<CmpDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmpDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
