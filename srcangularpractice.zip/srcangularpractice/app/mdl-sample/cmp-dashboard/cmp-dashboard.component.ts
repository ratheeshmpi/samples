import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,Validators,NgForm } from '@angular/forms';
import { user } from '../Classes/dashboard';
import { InsertValueService } from 'src/app/Services/insert-value.service';
import { error } from 'util';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cmp-dashboard',
  templateUrl: './cmp-dashboard.component.html',
  styleUrls: ['./cmp-dashboard.component.css']
})
export class CmpDashboardComponent implements OnInit {
  objUserDetail: user[];
  constructor(private _appService: InsertValueService,
    private router: Router) { }

  ngOnInit() {
    debugger;
    this.GetUserDetails();

  }
  GetUserDetails(){
    debugger;
    this._appService.GetUserDetails()
    .subscribe(
      (data: user[]) =>{
        this.objUserDetail =   data;
      },
      error =>{

      }
    );
  }


}





