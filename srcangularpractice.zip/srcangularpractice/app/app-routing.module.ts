import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CmpInsertComponent } from './mdl-sample/cmp-insert/cmp-insert.component';
import { CmpEditComponent } from './mdl-sample/cmp-edit/cmp-edit.component';
import { CmpDeleteComponent } from './mdl-sample/cmp-delete/cmp-delete.component';
import { CmpDashboardComponent } from './mdl-sample/cmp-dashboard/cmp-dashboard.component';


const routes: Routes = [
{path:"Insert",component:CmpInsertComponent},
{path:"Edit",component:CmpEditComponent},
{path:"Delete",component:CmpDeleteComponent},
{path:"Dashboard",component:CmpDashboardComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
