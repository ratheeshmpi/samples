import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{from, observable, Observable} from 'rxjs';
import{InsertValue} from '../Classes/Insert';


@Injectable({
  providedIn: 'root'
})
export class InsertValueService {
  private readonly url="https://localhost:5001/api/"

  constructor(private http:HttpClient) { }

  AddInsertValue(ObjInsertValue:InsertValue):Observable<any> {
    debugger;
return this.http.post(this.url+'Employee/EmployeeAdd/',ObjInsertValue, {responseType:'text'});
}
GetUserDetails():Observable<any>
{
return this.http.get(this.url+'Employee/EmployeeList');

}
EditUserDetails(objInsertValue:InsertValue):Observable<any>
{
  return this.http.post(this.url+'Employee/EmployeeEdit/',objInsertValue,{responseType:'text'})
}
DeleteUserDetails(objinsert:InsertValue):Observable<any>
  {
    return this.http.post(this.url+'Employee/EmployeeDelete',objinsert,{responseType:'text'});
  }



}
