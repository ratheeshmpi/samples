import { TestBed } from '@angular/core/testing';

import { InsertValueService } from './insert-value.service';

describe('InsertValueService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InsertValueService = TestBed.get(InsertValueService);
    expect(service).toBeTruthy();
  });
});
