namespace StudentMgt.Models
{
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System;
    using System.Data;
    public class StudentDAL
    {
        string strConn = "Server=MPI-CPU-102\\SQLEXPRESS;Database=StudentMgt;User Id=sa;Password=m@jdev1";

        public IEnumerable<Student> GetStudents(){
            List<Student> lstStudent = new List<Student>();
            Student objStu = new Student();
            using (SqlConnection dbConn = new SqlConnection(strConn))
            {
                dbConn.Open();
                SqlCommand dbCmd = new SqlCommand("SELECT * FROM [tblStudent]", dbConn);
                dbCmd.CommandType =CommandType.Text;

                SqlDataReader dbRead = dbCmd.ExecuteReader();
                while(dbRead.Read()){
                    objStu = new Student();
                    objStu.StuID = Convert.ToInt32(dbRead["StuID"]);
                    objStu.StuCode = dbRead["StuCode"].ToString();
                    objStu.StuName = dbRead["StuName"].ToString();
                    lstStudent.Add(objStu);
                }  
                dbConn.Close();
            }
            return lstStudent;
        }

        public bool CreateStudent(Student oStu){
            bool isSaved = true;
            string strSQL = $"INSERT INTO [tblStudent]  (StuCode, StuName) VALUES('{oStu.StuCode}', '{oStu.StuName}' )";
            using (SqlConnection dbConn = new SqlConnection(strConn))
            {
                dbConn.Open();
                SqlCommand dbCmd = new SqlCommand(strSQL, dbConn);
                dbCmd.CommandType = System.Data.CommandType.Text;
                dbCmd.ExecuteNonQuery();
                dbConn.Close();
            }

            return isSaved;
        }
    }
}