namespace StudentMgt.Models
{
    public class Student
    {
        public int StuID { get; set; }
        public string StuCode { get; set; }
        public string StuName { get; set; }
    }

}