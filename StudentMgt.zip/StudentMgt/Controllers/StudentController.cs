namespace StudentMgt.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using StudentMgt.Models;

    public class StudentController : Controller
    {
        public IActionResult Index(){
            StudentDAL objDAL = new StudentDAL();
            List<Student> objStud = new List<Student>();
            objStud = (List<Student>)objDAL.GetStudents();
            return View(objStud);
        }

        public IActionResult Create(){
            
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student oStu){
            new StudentDAL().CreateStudent(oStu);
            return RedirectToAction("Index");
        }
    }
}