namespace EmpMgt.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using EmpMgt.Models;
    public class EmployeeController:Controller
    {
        public IActionResult Index(){
     empDAL objDAL=new empDAL();
     List<employee> oemp=new List<employee>();
     oemp=(List<employee>)objDAL.GetEmployees();
            return View(oemp);
        }
public IActionResult Create()
{
return View();


}
 [HttpPost]
 public IActionResult Create(employee oempp){
 new empDAL().CreateEmployee(oempp);
 return RedirectToAction("Index");

 }
 public IActionResult Update()
 {
     return View();
 }
 [HttpPost]
 public IActionResult Update(employee oempp)
 {
     new empDAL().Update(oempp);
     return RedirectToAction("Index");
 }
 public IActionResult Delete()
 {
     return View();
 }
 [HttpPost]
 public IActionResult Delete(employee oempp)
 {
     new empDAL().Delete(oempp);
     return RedirectToAction("Index");
 }

    }
}