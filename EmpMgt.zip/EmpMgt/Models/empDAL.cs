namespace EmpMgt.Models

{
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System;
    using System.Data;
    
    public class empDAL
    {
       string strcon="Server=MPI-CPU-102\\SQLEXPRESS;Database=mvc;User Id=sa;Password=m@jdev1";
       public IEnumerable<employee> GetEmployees()
       {
          List<employee>lstemployee=new List<employee>();
          employee objemp=new employee();
          using(SqlConnection con =new SqlConnection(strcon))
         {
            con.Open();
            SqlCommand cmd=new SqlCommand("select *from employee",con);
            cmd.CommandType=CommandType.Text;
            SqlDataReader da = cmd.ExecuteReader();
            while(da.Read())
            {
              objemp=new employee();
              objemp.Emp_id=Convert.ToInt32(da["Emp_id"]);
              objemp.Name=da["Name"].ToString();
              objemp.Designation=da["Designation"].ToString();
              objemp.Salary=da["Salary"].ToString();
              lstemployee.Add(objemp);
            }             
               con.Close();
         }  
            return lstemployee;
      }
      public bool CreateEmployee(employee oem)
       {
         bool isSaved=true;
         string str=$"INSERT INTO [EMPLOYEE] (Name,Designation,Salary) VALUES('{oem.Name}','{oem.Designation}','{oem.Salary}')";
         using(SqlConnection con=new SqlConnection(strcon))
         {
           con.Open();
           SqlCommand cmd= new SqlCommand(str,con);
           cmd.CommandType=CommandType.Text;
           cmd.ExecuteNonQuery();
           con.Close();
         }
           return isSaved;
       }
      public void Update(employee oem)    
        { 
          using (SqlConnection con = new SqlConnection(strcon))     
           {     
             SqlCommand cmd = new SqlCommand("sp_update_employee", con);    
             con.Open(); 
             cmd.CommandType = CommandType.StoredProcedure;                    
             cmd.Parameters.AddWithValue("@Emp_id", oem.Emp_id);         
             cmd.Parameters.AddWithValue("@Name", oem.Name);  
             cmd.Parameters.AddWithValue("@Designation", oem.Designation); 
             cmd.Parameters.AddWithValue("@salary", oem.Salary);           
             cmd.ExecuteNonQuery();  
             con.Close(); 
            }
         }
         public void Delete(employee oem)
         {
            string str=$"DELETE from employee where Emp_id='{oem.Emp_id}' ";
         //string str=$"DELETE FROM employee WHERE Emp_id='{oem.Emp_id}'";
            using(SqlConnection con=new SqlConnection(strcon))
            {
              con.Open();
             SqlCommand cmd=new SqlCommand(str,con);
             cmd.CommandType=CommandType.Text;
             cmd.ExecuteNonQuery();
             con.Close();

            }
         }
}
}


