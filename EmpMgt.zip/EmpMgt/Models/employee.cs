namespace EmpMgt.Models
{
    public class employee
    {
        public int Emp_id {get;set;}
        public string Name{get;set;}
        
        public string Designation{get;set;}
        public string Salary{get;set;}
    }
}